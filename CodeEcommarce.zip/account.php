    <?php include_once('./components/db.php');
    ?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ONLY ORDER</title>
        <link rel="stylesheet" href="assets/bootstrap.css">
        <link rel="stylesheet" href="assets/customStyle.css">
        <link rel="stylesheet" href="assets/fontawesome/css/fontawesome.min.css">

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" />


    </head>


    <body>









        <script src="assets/bootstrap.bundle.min.js"></script>

        <script src="assets/fontawesome/fontawesome-free-5.15.4-web/js/all.js"></script>


        <script src="assets/ajax ofline.js"></script>
        <script src="assets/jquery.min.js"></script>
        <script src="assets/customscript.js"></script>


    </body>

    </html>