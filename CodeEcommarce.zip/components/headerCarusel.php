<div id="carouselId" class="carousel slide" data-bs-ride="carousel">
    <ol class="carousel-indicators">
        <li data-bs-target="#carouselId" data-bs-slide-to="0" class="active" aria-current="true"
            aria-label="First slide"></li>
        <li data-bs-target="#carouselId" data-bs-slide-to="1" aria-label="Second slide"></li>
        <li data-bs-target="#carouselId" data-bs-slide-to="2" aria-label="Third slide"></li>
    </ol>
    <div class="carousel-inner" role="listbox">
        <div class="carousel-item active">
            <img class="headerCaruselImg" src="assets/img/b10.jpg" class="w-100 d-block" alt="First slide">
            <div class="carousel-caption d-none d-md-block">
                <h3 class="headerCaruselTitle">ONLY ORDER </h3>
                <p class="headerCaruselDes"> this is a header area carusel title number </p>
            </div>
        </div>
        <div class="carousel-item">
            <img class="headerCaruselImg" src="assets/img/12a.jpg" class="w-100 d-block" alt="Second slide">
            <div class="carousel-caption d-none d-md-block">
                <h3 class="headerCaruselTitle">Custumars</h3>
                <p class="headerCaruselDes">this is a ONLY ORDER bset customars <a href="components/promote.php"> Click
                        Here</a>
                </p>
            </div>
        </div>
        <div class="carousel-item">
            <img class="headerCaruselImg" src="assets/img/b1-1.jpg" class="w-100 d-block" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
                <h3 class="headerCaruselTitle">Specal Product</h3>
                <p class="headerCaruselDes"> this is a specal product link <a href="components/promote.php"> Click
                        Here</a></p>
            </div>
        </div>
    </div>
</div>