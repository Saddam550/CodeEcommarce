<script src="../assets/ajax ofline.js"></script>
<script src="../assets/jquery.min.js"></script>

<script src="../assets/bootstrap.bundle.min.js"></script>
</body>

</html>