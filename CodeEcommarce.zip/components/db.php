<?php
$host = "sql104.liveblog365.com";
$user = 'lblog_33920143';
$bd = "lblog_33920143_codeecommarce";
$pass = "admin123";

$dbConnenttion = mysqli_connect($host, $user, $pass, $bd);




