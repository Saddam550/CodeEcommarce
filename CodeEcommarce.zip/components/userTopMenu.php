<div class="userInfoHeader">
    <div class="userName userin"><a href="">

            <i class="fa-solid fa-user"></i>

        </a></div>
    <div class="usercard userin"><a href="">

            <i class="fa-solid fa-bag-shopping"></i>

        </a></div>
    <div class="userLogout userin"><a href="">
            <i class="fa-solid fa-right-from-bracket"></i>


        </a>
    </div>
</div>