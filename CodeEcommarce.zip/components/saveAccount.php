<?php

include_once("db.php");

include_once("htmlTopCode.php");

if (isset($_POST["full_name"]) && isset($_POST["email_add"]) && isset($_POST["country"]) && isset($_POST["StreetAddress"]) && isset($_POST["city"]) && isset($_POST["Zip"]) && isset($_POST["state"])) {

    $full_name = $_POST["full_name"];
    $email_add = $_POST["email_add"];
    $country = $_POST["country"];
    $StreetAddress = $_POST["StreetAddress"];
    $city = $_POST["city"];
    $Zip = $_POST["Zip"];
    $state = $_POST["state"];




    $InsertUserInfo = "INSERT INTO account( userName, userEmail, userCountry, userStreet_Address, userCity, userZip, userState) VALUE('$full_name', '$email_add', '$country', '$StreetAddress', '$city', '$Zip', '$state' )";


    if ($InsertUserInfo) {
        $quary = mysqli_query($dbConnenttion, $InsertUserInfo);
        if ($quary) {
            $amount = $_POST["amount"];

?>

            <div class="container-fluid">
                .<div class="row justify-content-center align-items-center g-2">
                    <div class="col">
                        <form action="../paymentSystem/process.php" method="post" id="autoSubmit">

                            <input type="hidden" name="amount" value="<?php $amount ?>">
                            <input type="hidden" name="full_name" value="<?php $full_name ?>">
                            <input type="hidden" name="email_add" value="<?php $email_add ?>">
                            <input type="submit" style="visibility:hidden;">

                        </form>
                    </div>

                </div>
            </div>



        <?PHP

        } else {
            echo "insrt";
        }
    } else {
        echo "saddam";
    }
} else {
    echo "saddam";
}


if (isset($_POST["totalPrice"]) && isset($_POST["productImg"]) && isset($_POST["productName"]) && isset($_POST["code"])) {
    $productName = $_POST["productName"];
    $totalPrice = $_POST["totalPrice"];
    $productImg = $_POST["productImg"];
    $code = $_POST["code"];
    include_once("db.php");


    $InserorderInfo =  " INSERT INTO `order`(`orderProductName`,	`orderProductPrice`,	`orderProductImg`, `orderCode`) VALUE('$productName', '$totalPrice', '$productImg', '$code')";

    if ($InserorderInfo) {
        $quarys = mysqli_query($dbConnenttion, $InserorderInfo);

        if ($quarys) {

        ?>
            <?php include_once("htmlButtonCode.php"); ?>
            <script>
                setInterval(() => {
                    $("#autoSubmit").submit()
                }, 2000);
            </script>

            <div class="orderLoding">
                <img src="../assets/loading/loading.gif" class="img-fluid rounded-top" alt="">
            </div>
<?php

        } else {
            echo "Your Order filed. try aging...";
            echo "<a class='btn btn-danger' href='../chackout.php'> Go To ChackOut Page </a>";
        }
    } else {
        echo "not insert ";
    }
}

?>