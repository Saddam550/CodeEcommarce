<ul class="nav nav" id="adminNavBar" role="tablist">
    <li class="nav-item">
        <div class="userName nav-item">
            <h5 class="nav-item"><img src="../../assets/img/b12.jpg" alt="" srcset=""> <span>Admin:
                    Saddam Hossen </span>
            </h5>
        </div>
    </li>

    <li class="nav-item" role="presentation">
        <a href="../index.php" class="nav-link">Product Add</a>
    </li>
    <li class="nav-item" role="presentation">
        <a href="ProductEdit.php" class="nav-link">Product Edit</a>
    </li>
    <li class="nav-item" role="presentation">
        <a href="ProductDelete.php" class="nav-link">product Delete</a>
    </li>
    <li class="nav-item" role="presentation">
        <a href="allProduct.php" class="nav-link"> Product All</a>
    </li>
    <li class="nav-item" role="presentation">
        <a href="orderpage.php" class="nav-link">Order</a>
    </li>
    <li class="nav-item" role="presentation">
        <a href="userAccount.php" class="nav-link">users</a>
    </li>
    <li class="nav-item" role="presentation">
        <a href="../../index.php" class="nav-link">Go To Site</a>
    </li>
    <li class="nav-item" role="presentation">
        <a href="../adminLogout.php" class="nav-link">Logout</a>
    </li>

</ul>